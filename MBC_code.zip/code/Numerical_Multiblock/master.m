
run("A1_M_BC_EX1.m")    % Table 3, Example 1, use M-BC with small problem instance 
run("A1_M_BC_EX2.m")    % Table 3, Example 2, use M-BC with small problem instance 
run("A1_M_BC_EX3.m")    % Table 3, Example 3, use M-BC with small problem instance 
run("A2_H_BC_EX1.m")    % Table 3, Example 1, use H-BC with small problem instance 
run("A2_H_BC_EX2.m")    % Table 3, Example 2, use H-BC with small problem instance 
run("A2_H_BC_EX3.m")    % Table 3, Example 3, use H-BC with small problem instance 
run("A3_S_BC_EX1.m")    % Table 3, Example 1, use S-BC with small problem instance 
run("A3_S_BC_EX2.m")    % Table 3, Example 2, use S-BC with small problem instance 
run("A3_S_BC_EX3.m")    % Table 3, Example 3, use S-BC with small problem instance 
run("A4_M_BC_V_EX1.m")  % Table 7, Example 1, use M-BC-V with small problem instance 
run("A4_M_BC_V_EX2.m")  % Table 7, Example 2, use M-BC-V with small problem instance 
run("A4_M_BC_V_EX3.m")  % Table 7, Example 3, use M-BC-V with small problem instance 
run("A5_M_BC_VS_EX1.m") % Table 7, Example 1, use M-BC-VS with small problem instance 
run("A5_M_BC_VS_EX2.m") % Table 7, Example 2, use M-BC-VS with small problem instance 
run("A5_M_BC_VS_EX3.m") % Table 7, Example 3, use M-BC-VS with small problem instance 
